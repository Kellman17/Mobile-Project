package com.example.myapplication

class AppConfig {
    var IP_SERVER = "http://192.168.100.2"
}