package com.example.myapplication

data class Lukisan(var id: Int, var id_pembelian: Int, var image: String, var judul: String, var deskripsi: String, var kategori: String, var harga_jual: Int)