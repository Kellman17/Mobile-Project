package com.example.myapplication

data class DataAdmin(var id: Int, var email: String, var username: String)